package income;
public class Individual extends Guest {

  // set items of stock and using super to read the items from parent class
  public Individual (){
      super(1,1,0,1,0); 
  } 
   

}
   
   