package income;
public class Group extends Guest {

   // set items of stock and using super to read the items from parent class
   public Group () {
      super(4,3,3,4,3);
   }
   
   
}   