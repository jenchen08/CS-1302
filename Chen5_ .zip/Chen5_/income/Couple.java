package income;
public class Couple extends Guest {

	// set items of stock and using super to read the items from parent class
   public Couple() {
      super(2,1,1,2,1);
   }
   
   
}