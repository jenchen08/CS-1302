package income;

//***************************************************************************************
// Purpose: Practice with Inheritance, polymorphism, and random class
//
// Input: Set stock of what they order
// Output:
//
// Author: Jenny Chen
// Course: 1302 A
// Date: 2/7/18
// Program: Individual.java
// **************************************************************************************

public class Individual extends Guest {
	// set items of stock and using super to read the items from parent class
	public Individual() {
		super(1, 1, 0, 1, 0);
	}

}
   
   