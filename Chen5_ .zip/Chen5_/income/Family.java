package income;
//***************************************************************************************
	// Purpose: Practice with Inheritance, polymorphism, and random class
	//
	// Input: Set stock they order
	// Output:
	//
	// Author: Jenny Chen
	// Course: 1302 A
	// Date: 2/7/18
	// Program: Family.java
	// **************************************************************************************
public class Family extends Guest {

   // set items of stock and using super to read the items from parent class
   public Family(){
      super(4,2,3,4,2);
   }

}
   